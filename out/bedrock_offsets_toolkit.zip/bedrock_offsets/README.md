# bedrock_offsets — symbol-based offset recovery for Minecraft Bedrock

Recovers real function addresses from `libminecraftpe.so` **without** a
decompiler, by exploiting entt system metadata that Bedrock keeps in
`.data.rel.ro`.

## Why this works

The library exports 91,693 `.dynsym` entries, but these are only third-party
code (cohtml, V8, WebRTC, Xbox) plus JNI. Bedrock's own classes are stripped.
However every registered ECS system has a metadata record holding a pointer to
its **mangled C++ name**. In a PIC shared object each such pointer is an
`R_AARCH64_RELATIVE` relocation whose addend is the final VA. Therefore:

    name string --(reloc addend)--> pointer slot --(sibling relocs)--> functions

That is exact, not heuristic.

## Requirements

    pip install capstone pyelftools

## Usage

    python recover.py path/to/libminecraftpe.so --json out.json

Prints one row per hook: resolved address, how it was resolved, owning system.

    python symtable.py tickPlayerWaterGravity     # name -> slots -> function ptrs
    python nameres.py 'CameraBobSystem::tick'     # all fns in that system's record
    python entry.py 0xcd226ec                     # interior addr -> proven entry
    python body.py 0xcd2266c                      # constants materialised in body

## Modules

| file | purpose |
|---|---|
| `bedrock_re.py` | ELF load, segment/section map, string + xref primitives |
| `symtable.py` | relocations -> reverse map `addend -> slots` |
| `nameres.py` | mangled-name index; `Class::method` -> function pointers |
| `body.py` | bounded body scan for `movz/movk + fmov` f32 constants |
| `entry.py` | interior pointer -> true entry, proven by forward decode |
| `recover.py` | end-to-end: spec in, address table out |
| `systems.py` | entt record parser (0x80-stride layout) |
| `callers.py` | `bl` target reverse index |
| `const_scan.py` | whole-`.text` constant sweep with register tracking |

## Key facts about 1.26.66.1 arm64

* `.text` `0x6834D60`–`0x135D3F00`
* `.rodata` `0x2419F80`–`0x37860B4`, 7,504 mangled names, 190,777 strings total
* `.data.rel.ro` `0x1368B520`, 868,396 `R_AARCH64_RELATIVE` relocs
* `-0.08` and `-0.01` are **never stored as floats** in the file; they are built
  via `mov w,#0xd70a; movk w,#0xbda3,lsl#16` (land) and `#0xbc23` (water).
  Any scanner looking for raw f32 literals reports a false negative.
* Constants like these are unreachable by `fmov`-immediate decoding either,
  because VFPExpandImm can only encode `(16+f)/16 * 2^(e-3)`.

## Limits

Classes absent from every symbol source (`Actor`, `Player`, `GameMode`,
`ClientInstance`, `LevelRenderer`, `BlockSource`, ...) cannot be resolved from
the file. Their methods are only reachable through vtable slot indices, which
must be discovered at runtime.
